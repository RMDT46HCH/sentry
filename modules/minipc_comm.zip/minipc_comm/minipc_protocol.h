#ifndef __minipc_protocol_H
#define __minipc_protocol_H

#include <stdio.h>
#include <stdint.h>
#include "minipc_comm.h"

#define MINIPC_CMD_ID 0xA4
#define SEND_MINIPC_ID 0x4A

#endif
